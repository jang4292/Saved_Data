#ifndef __AUTOBUILD_H__
#define __AUTOBUILD_H__
//change the FALSE to TRUE for autoincrement of build number
#define INCREMENT_VERSION FALSE
#define FILEVER        1,0,0,1
#define PRODUCTVER     1,0,0,1
#define STRFILEVER     "1, 0, 0, 1\0"
#define STRPRODUCTVER  "1, 0, 0, 1\0"
#endif //__AUTOBUILD_H__
