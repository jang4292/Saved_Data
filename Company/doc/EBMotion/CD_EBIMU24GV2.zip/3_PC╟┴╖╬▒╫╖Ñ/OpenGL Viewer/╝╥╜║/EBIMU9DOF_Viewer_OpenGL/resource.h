//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_DIALOG1                     101
#define IDC_COMPORT                     1001
#define IDC_CONNECT                     1003
#define IDC_PROG_PITCH                  1005
#define IDC_PROG_ROLL                   1006
#define IDC_PROG_YAW                    1007
#define IDC_DEGPITCH                    1008
#define IDC_DEGROLL                     1009
#define IDC_DEGYAW                      1010
#define IDC_SLIDER1                     1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
